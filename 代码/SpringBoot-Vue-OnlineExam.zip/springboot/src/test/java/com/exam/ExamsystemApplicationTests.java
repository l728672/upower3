package com.exam;

import com.exam.entity.FillQuestion;
import com.exam.entity.JudgeQuestion;
import com.exam.entity.MultiQuestion;
import com.exam.service.FillQuestionService;
import com.exam.service.JudgeQuestionService;
import com.exam.service.MultiQuestionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ExamsystemApplicationTests {

    @Autowired
    MultiQuestionService multiQuestionService;

    @Autowired
    JudgeQuestionService judgeQuestionService;

    @Autowired
    FillQuestionService fillQuestionService;

    @Test
    public void contextLoads() {
        for (int i = 0; i < 10000; i++) {
            multiQuestionService.add(new MultiQuestion(null, "计算机网络", "应运层", "将IP地址翻译为计算机名，为客户机分配IP地址", "将IP地址翻译为计算机名、解析计算机的MAC地址", "将计算机名翻译为IP地址、为客户机分配IP地址", "将计算机名翻译为IP地址、解析计算机的MAC地址", "DNS 服务器和DHCP服务器的作用是（）"+i, "2", "C",null,2));
        }
        for (int i = 0; i < 10000; i++) {
            judgeQuestionService.add(new JudgeQuestion(null, "计算机网络", "与有线网相比,无线网的数据传输率一般相对较慢"+i, "T", "1", null, 2, null));
        }
        for (int i = 0; i < 10000; i++) {
            fillQuestionService.add(new FillQuestion(null, "计算机网络", "从计算机网络系统组成的角度看，计算机网络可以分为()和()"+i, "通信子网资源子网", 2, "3", null, null));
        }
    }

}

